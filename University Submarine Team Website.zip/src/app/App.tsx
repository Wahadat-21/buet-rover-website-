import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import AboutUs from './pages/AboutUs';
import Sponsor from './pages/Sponsor';
import RoboSub from './pages/RoboSub';
import FerryDesign from './pages/FerryDesign';
import ContactUs from './pages/ContactUs';
import Stories from './pages/Stories';
import Members from './pages/Members';
import Papers from './pages/Papers';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<AboutUs />} />
          <Route path="/papers" element={<Papers />} />
          <Route path="/members" element={<Members />} />
          <Route path="/sponsor" element={<Sponsor />} />
          <Route path="/robosub" element={<RoboSub />} />
          <Route path="/ferry-design" element={<FerryDesign />} />
          <Route path="/contact" element={<ContactUs />} />
          <Route path="/stories" element={<Stories />} />
        </Routes>
      </div>
    </Router>
  );
}