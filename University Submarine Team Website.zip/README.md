
  # University Submarine Team Website

  This is a code bundle for University Submarine Team Website. The original project is available at https://www.figma.com/design/9hcpT4S9csSk40Twn5s74t/University-Submarine-Team-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  